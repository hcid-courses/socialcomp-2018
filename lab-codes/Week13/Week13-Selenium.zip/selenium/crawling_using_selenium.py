from bs4 import BeautifulSoup
from selenium import webdriver
import time

# url = "http://v.media.daum.net/v/20161103113844417"
url = "http://v.media.daum.net/v/20161120134647462"

driver = webdriver.Firefox()
driver.get(url)

found_element = True
while found_element:
    try:
        element = driver.find_element_by_xpath("//div[@class='alex_more']")
        element.click()
        time.sleep(3)

    except Exception:
        found_element = False

html = driver.page_source
soup = BeautifulSoup(html, "html.parser")

comments = soup.find_all("ul", class_="list_comment")
print(comments)
